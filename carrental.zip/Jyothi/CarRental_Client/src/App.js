import Login from "./login";
import Signup from "./signup";
import AppLog from "./AppLog";
import "./App.css";
export default function App() {
  return <AppLog />;
}
