import React, { useState, useEffect } from "react";
import "./CarStatus.css";
import Navbar from "./Navbar";
import Loadings from "./Loadings";

export default function CarStatus() {
  //----------Getting All bookings data--------------------------------------------

  let [AllBookings, setAllbookings] = useState([]);
  const getbookings = async () => {
    const response = await fetch("http://localhost:3500/bookingsdata", {
      method: "GET",
    });
    const data = await response.json();
    setAllbookings(data);
  };

  useEffect(() => {
    getbookings();
  }, []);

  let Loading = <Loadings />;
  let Maincon = (
    <>
      <Navbar />
      <div className="con">
        {AllBookings.map((car) => {
          car;
          return (
            <>
              <div
                class="card"
                style={{
                  margin: "10px ",
                  width: "320px",
                  boxShadow: "0px 4px 8px 0px black",
                  border: "none",
                }}
              >
                <img
                  src={car.BookingDetails.car_image}
                  class="card-img-top"
                  alt="carImage"
                />
                <div class="card-body" style={{ padding: "7px" }}>
                  <h5 class="card-title"> {car.BookingDetails.car_name}</h5>
                  <p class="card-text"></p>
                  <p>
                    <button
                      class="btn btn-primary btn-sm"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#collapseExample"
                      aria-expanded="false"
                      aria-controls="collapseExample"
                      style={{ margin: "0px 0px 5px 0px" }}
                    >
                      Show Status
                    </button>
                  </p>
                  <div class="collapse" id="collapseExample">
                    <div class="card card-body" style={{ padding: "4px" }}>
                      <table>
                        <tr>
                          <td>From Time</td>
                          <td className="cen">:</td>
                          <td>{car.BookingDetails.StartTime}</td>
                        </tr>
                        <tr>
                          <td>To Time</td>
                          <td className="cen">:</td>
                          <td>{car.BookingDetails.EndTime}</td>
                        </tr>
                        <tr>
                          <td>Total Rent</td>
                          <td className="cen">:</td>
                          <td>{car.BookingDetails.car_rent}/-</td>
                        </tr>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </>
          );
        })}
      </div>
    </>
  );
  return AllBookings.length !== 0 ? Maincon : Loading;
}
